/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package application;

/**
 *
 * @author ASUS VivoBook
 */
public class main {
    public static void main(String[] args) {
        // Menggunakan polymorphism
      Register reg = new Register();

        // Menampilkan informasi menggunakan interface
        reg.setVisible(true);
    }
}