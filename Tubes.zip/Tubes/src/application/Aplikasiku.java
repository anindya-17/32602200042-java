
package application;

public class Aplikasiku {
  // Interface
interface Register {
    void Register();
}

// Base class menggunakan inheritance dan encapsulation
class Aplikasiku implements Aplikasiku  {
    private String username;
    private String password;

    // Constructor
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Getter dan Setter menggunakan encapsulation
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Implementasi dari interface Displayable
  
    public void Register() {
        System.out.println("Username: " + username);
    }
}

// Subclass menggunakan inheritance dan polymorphism
class Register extends main {
    private String email;

    // Constructor
    public Register(String username, String password) {
        super(username, password);
       
    }

    // Getter dan Setter menggunakan encapsulation
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Override metode display dari interface Displayable
    @Override
    public void Register() {
        super.Register();
    }
}

}
